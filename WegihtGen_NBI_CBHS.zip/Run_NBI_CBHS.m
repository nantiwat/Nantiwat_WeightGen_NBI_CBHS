clear all
clc


ps1=[{'1 2 3 4 5 6'}
     {'1 2 3 4 5 6'}
     {'1 2 3 4'}
     {'1 2 3'}
     {'1 2'}
     {'1 2'}];
p2=0; 
di=[3 5 7 10 13 15] ;
nrun=1;
for i=1 %%% no objective
    i
    p1=char(ps1(i,:));
    p1=str2num(p1);
    for j=1:length(p1)
        
        tNB0=tic;
        [N,W] = NBI(p1(j),p2,di(i));%normal boundary intersection method, Das and Dennis�s technique
        tNBI(j)=toc(tNB0);
        [nsp(j),nd(j)]=size(W);
        PhiNBI(j)=mmphi(W)
        nsampling=nsp(j);  %%%%%% no of sampldi(i)ng
        
        
        for k=1:nrun
            tCBHS=tic;
            W04=CBHS(nd(j),nsampling);
            tCBHS(k,j)=toc(tCBHS);
            PhiCBHS0(k,j)=mmphi(W04');
        end
        PhiCBHS(j)=mean(PhiCBHS0(k,j))
    end

end

        
        

