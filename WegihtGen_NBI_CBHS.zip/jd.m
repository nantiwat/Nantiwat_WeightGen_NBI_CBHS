function [J,distinct_d]=jd(X,p)
if ~exist('p','var')
    p=1;
end
n=size(X,1);
d=zeros(1,n*(n-1)/2);
for i=1:n-1
    for j=i+1:n
        d((i-1)*n-(i-1)*i/2+j-i)=norm(X(i,:)-X(j,:),p);
    end
end
distinct_d=unique(d);
J=zeros(size(distinct_d));
for i=1:length(distinct_d)
    J(i)=sum(ismember(d,distinct_d(i)));
end