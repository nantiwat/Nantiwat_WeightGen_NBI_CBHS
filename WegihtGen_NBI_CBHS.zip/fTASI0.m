function iselect=fTASI(f,Nmem);
[nvar,Npop]=size(f);
Nremove=Npop-Nmem;
% Compute Eucledian distance 
for i=1:Npop
    fi=f(:,i);
    D(i,i)=0;% Eucledian distance
    for j=(i+1):Npop;
        fj=f(:,j);
        D(i,j)=sum((fi-fj).*(fi-fj));D(j,i)=D(i,j);
    end
end
[Dsort,nsort]=sort(D,2);
KK=1:Npop;
iremove=[];
while length(iremove)<Nremove
    k=2;
    [dksort,nks]=sort(Dsort(:,k));
    nks1=nks(1);nks2=nks(2);
    if nks1<=nvar
        irm=nks2;
    elseif nks2<=nvar
        irm=nks1;
    else
        sw=1;
        while sw
            [dksort,nks]=sort(Dsort(:,k));
            if dksort(1)==dksort(2)
                k=k+1;
            else
                sw=0;
            end
        end
        irm=nks(1);
    end
    iremove=[iremove KK(irm)];
    KK(nks(1))=[];
    D(nks(1),:)=[];
    D(:,nks(1))=[];
    [Dsort,nsort]=sort(D,2);
end
iselect=setdiff(1:Npop,iremove);
% figure(1),clf,hold on
% plot3(f(1,:),f(2,:),f(3,:),'s')
% plot3(f(1,iselect),f(2,iselect),f(3,iselect),'ro')


