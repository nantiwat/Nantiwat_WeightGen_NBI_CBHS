function w=CBHS(M,n)

t=2;% 
n1=t*M*n;% no. of points to be randomly created
nstep=1;% no. of steps to operate TASI
n2=M*n;
% sampling n1 points on a hyperplane
anchors=eye(M);
for i=1:n1
    Ish=randperm(M);
    alpha1=rand;alpha2=rand;
    delw=(1-alpha1)*anchors(:,Ish(2))+alpha1*anchors(:,Ish(3));
    w0(:,i)=(1-alpha2)*anchors(:,Ish(1))+alpha2*delw;
end
w00=KmeanClustering(w0,n2);

%%%%%%%%%%%%%%%%%
w=[eye(M) w00];
for i=1:size(w,2)
    wi=w(:,i);
    D(i,i)=0;% Eucledian distance
    for j=(i+1):size(w,2);
        wj=w(:,j);
        D(i,j)=sum((wi-wj).*(wi-wj));D(j,i)=D(i,j);
    end
end
%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%
n2=M+n2;
irm=ceil((n2-n)/nstep)*ones(1,nstep);
irm(end)=n2-sum(irm(1:end-1))-n;
% irm=size(w,2)-n;
for ii=irm
    [w,D]=fTASI(w,ii,M,D);  
end




%%%%% sub-functions %%%%
function cenT=KmeanClustering(Xbase,nsamp)
[idx,cenT]=kmeans(Xbase',nsamp);
cenT=cenT';
%%%%%%%%%%%%%%%
function [iselect,D]=fNNM(D,narchive)
[Ds,sortd]=sort(D,2);
k=3;
sigmak=Ds(:,k);
[sortedsigmak,nsort]=sort(-sigmak);
iselect=nsort(1:narchive);
D(:,iselect)=[];
D(iselect,:)=[];
%%%%%%%%%%%%%%%
function [f,D]=fTASI(f,Nremove,M,D);
[nvar,Npop]=size(f);
% Compute Eucledian distance 

[Dsort,nsort]=sort(D,2);
KK=1:Npop;
iremove=[];
while length(iremove)<Nremove
    k=2;
    [dksort,nks]=sort(Dsort(:,k));
    nks1=nks(1);nks2=nks(2);
    if nks1<=nvar
        irm=nks2;
    elseif nks2<=nvar
        irm=nks1;
    else
        sw=1;
        while sw
            [dksort,nks]=sort(Dsort(:,k));
            if dksort(1)==dksort(2)
                k=k+1;
            else
                sw=0;
            end
        end
        irm=nks(1);
    end
    iremove=[iremove KK(irm)];
    KK(irm)=[];
    D(irm,:)=[];
    D(:,irm)=[];
    [Dsort,nsort]=sort(D,2);
end
iselect=setdiff(1:Npop,iremove);
f=f(:,iselect);
%%%%%%%%%%%%%%%%%


